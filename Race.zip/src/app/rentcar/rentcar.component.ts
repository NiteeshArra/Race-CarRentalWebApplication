import { Component, OnInit } from '@angular/core';
import { PersonService } from '../person.service';
import * as bootstrap from 'bootstrap';
import * as $ from "jquery";
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-rentcar',
  templateUrl: './rentcar.component.html',
  styleUrls: ['./rentcar.component.css']
})
export class RentcarComponent implements OnInit {
customer:any
cars:any;
car:any;
editObject :any;
customeremail:any;
index=0;
  constructor(public service: PersonService,public router: Router, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
        
        this.customeremail= params["customeremail"];  
    });}

  ngOnInit(): void {
    this.editObject = {carModel: '', carRegistrationNumber: '', startingPoint:'', startDate:'', hour: '', minute: '', endDate: '', destination: '', kilometersTravelled: '',rentPayable: ''};
  }

  showEditPopup(car:any) :void{
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "carmodel": car.carModel,
          "owneremail": car.ownerEmailId,
          "carRegistrationNumber":car.carRegistrationNumber,
          "availablelocation":car.availableLocation,
          "priceperkm":car.pricePerKm,
          "customeremail":this.customeremail
      }
  };
    
    this.router.navigate(['/bookcar'], navigationExtras);
  }

  getCarsByLocation(searchForm: any) : void {
    console.log(searchForm);

    this.service.getCars(searchForm.availableLocation).toPromise().then((data: any)=> {this.cars =data; console.log(data)});

  }


  async view(){
    await this.service.customerProfile(this.customeremail).toPromise().then((data: any)=> {this.customer =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "customername": this.customer.customerName,
          "customeremail": this.customer.customerEmailId,
          
         
      }
  };
    this.router.navigate(['/customerhome'], navigationExtras);
  }
 
 
}
