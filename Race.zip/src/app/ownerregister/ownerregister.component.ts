import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';
@Component({
  selector: 'app-ownerregister',
  templateUrl: './ownerregister.component.html',
  styleUrls: ['./ownerregister.component.css']
})
export class OwnerregisterComponent implements OnInit {
  
  
  ownerregister: any;
 
  constructor(public router: Router, public service: PersonService,private toastr: ToastrService) { }

  ngOnInit() {
  }



  registerOwner(ownerForm: any) : void {
    console.log(ownerForm);
 if(ownerForm.ownerEmailId!="" && ownerForm.ownerName!="" && ownerForm.password!="" && ownerForm.repassword!="" && ownerForm.gender!="" && ownerForm.ownerLicenseNumber!="" && ownerForm.ownerPhoneNumber!="" && ownerForm.state!="" && ownerForm.city!="" && ownerForm.postal!="" )
 {
    this.service.registerOwnerDetails(ownerForm).subscribe((result: any) => console.log(result));
    this.toastr.success('successfully registered', '');
    this.router.navigate(['login']);
 }
 else
 {
  this.toastr.error('Please enter the details', '');
 }
}



}
