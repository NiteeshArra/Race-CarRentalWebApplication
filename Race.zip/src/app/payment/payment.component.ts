import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {


customername:any;
customeremail:any;
customer:any
  constructor(public router: Router,public personService: PersonService, private route: ActivatedRoute,private toastr: ToastrService) {
    this.route.queryParams.subscribe(params => {
        this.customername= params["customername"];
        this.customeremail= params["customeremail"];
        
        

      
    });}

  ngOnInit(): void {
  }

  async pay(){
    this.toastr.success('Payment successful', '');
    await this.personService.customerProfile(this.customeremail).toPromise().then((data: any)=> {this.customer =data; console.log(data)});
    
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "customername": this.customer.customerName,
          "customeremail": this.customer.customerEmailId,
          
         
      }
  };
    this.router.navigate(['/customerhome'], navigationExtras);
  }

}
