import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
 customerDetails :any
 customeremail :any
 customername :any
 customerlicensenumber :any
 customerphonenumber :any
 state :any
 city :any
 postal :any

customer:any

  constructor(public router: Router,public personService: PersonService, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
        this.customername= params["customername"];
        this.customeremail= params["customeremail"];
        this.customerlicensenumber= params["customerlicensenumber"];
        this.customerphonenumber= params["customerphonenumber"];
        this.state= params["state"];
        this.city= params["city"];
        this.postal= params["postal"];
        

      
    });}

  ngOnInit(): void {
  }

  async viewProfile(){
    await this.personService.customerProfile(this.customeremail).toPromise().then((data: any)=> {this.customer =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "customername": this.customer.customerName,
          "customeremail": this.customer.customerEmailId,
          
         
      }
  };
    this.router.navigate(['/customerhome'], navigationExtras);
  }


}
