import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-addcar',
  templateUrl: './addcar.component.html',
  styleUrls: ['./addcar.component.css']
})
export class AddcarComponent implements OnInit {

ownername:any
owneremail:any
owner:any
  constructor(public router: Router,public service: PersonService, private route: ActivatedRoute,private toastr: ToastrService) {
    this.route.queryParams.subscribe(params => {
        this.ownername= params["ownername"];
        this.owneremail= params["owneremail"];
       
        

      
    });}

  ngOnInit(): void {
  }


  addCar(addcarForm :any) : void {
    addcarForm.ownerEmailId=this.owneremail;
    console.log(addcarForm);
    if(addcarForm.carRegistrationNumber!="" && addcarForm.carModel!="" && addcarForm.ownerEmailId!="" && addcarForm.underMaintainance!="" && addcarForm.availableLocation!="" && addcarForm.lastServiceDate!="" && addcarForm.isRented!="" && addcarForm.pricePerKm!="" )
    {
    this.service.addcarDetails(addcarForm).subscribe((result: any) => console.log(result));
   // alert("successfully added ");
   this.toastr.success('Car added successfully ', '');
    }
    else{
      this.toastr.error('Please enter the details', '');
    }
   
}

async view(){
  await this.service.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
  let navigationExtras: NavigationExtras = {
    queryParams: {
        "ownername": this.owner.ownerName,
        "owneremail": this.owner.ownerEmailId,
        
       
    }
};
  this.router.navigate(['/ownerhome'], navigationExtras);
}

}
