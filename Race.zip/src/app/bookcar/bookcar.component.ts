import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-bookcar',
  templateUrl: './bookcar.component.html',
  styleUrls: ['./bookcar.component.css']
})
export class BookcarComponent implements OnInit {
 customer:any
  carmodel:any;
  owneremail: any;
  carRegistrationNumber:any;
  availablelocation:any;
  priceperkm:any;
customeremail:any;

  constructor(public service: PersonService, private route: ActivatedRoute,public router: Router,private toastr: ToastrService) {
    this.route.queryParams.subscribe(params => {
        this.carmodel= params["carmodel"];
        this.owneremail= params["owneremail"];
        this.carRegistrationNumber= params["carRegistrationNumber"];
        this.availablelocation= params["availablelocation"];
        this.priceperkm= params["priceperkm"];
        this.customeremail= params["customeremail"];
        

      
    });}

  ngOnInit(): void {
  }

  bookCar(bookcarForm :any) : void {
    console.log(bookcarForm);
   
    if(bookcarForm.startDate!="" && bookcarForm.endDate!="" && bookcarForm.hour!="" && bookcarForm.minute!="" && bookcarForm.destination!="" )

{
    bookcarForm.kilometersTravelled=500;
    bookcarForm.rentPayable=this.priceperkm * 500;
    bookcarForm.carModel=this.carmodel;
    bookcarForm.ownerEmailId=this.owneremail;
    bookcarForm.customerEmailId=this.customeremail;
    bookcarForm.carRegistrationNumber= this.carRegistrationNumber;
    bookcarForm.startingPoint= this.availablelocation;
    this.service.bookCar(bookcarForm).subscribe((result: any) => console.log(result));
    //alert("successfully booked");
    this.toastr.success('successfully booked', '');
}
else
{
  this.toastr.error('Please enter the details', '');
}
}


async view(){
  await this.service.customerProfile(this.customeremail).toPromise().then((data: any)=> {this.customer =data; console.log(data)});
  let navigationExtras: NavigationExtras = {
    queryParams: {
        "customername": this.customer.customerName,
        "customeremail": this.customer.customerEmailId,
        
       
    }
};
  this.router.navigate(['/customerhome'], navigationExtras);
}



}
