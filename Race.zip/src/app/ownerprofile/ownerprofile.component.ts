import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-ownerprofile',
  templateUrl: './ownerprofile.component.html',
  styleUrls: ['./ownerprofile.component.css']
})
export class OwnerprofileComponent implements OnInit  {
  customerDetails :any
  owneremail :any
  ownername :any
  ownerlicensenumber :any
  ownerphonenumber :any
  state :any
  city :any
  postal :any
 owner:any
 
 
   constructor(public router: Router,public personService: PersonService, private route: ActivatedRoute) {
     this.route.queryParams.subscribe(params => {
         this.ownername= params["ownername"];
         this.owneremail= params["owneremail"];
         this.ownerlicensenumber= params["ownerlicensenumber"];
         this.ownerphonenumber= params["ownerphonenumber"];
         this.state= params["state"];
         this.city= params["city"];
         this.postal= params["postal"];
         
 
       
     });}
 
   ngOnInit(): void {
   }
 
   viewProfile(){
     this.customerDetails=this.personService.getCustomer();  
    
   }


   async view(){
    await this.personService.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "ownername": this.owner.ownerName,
          "owneremail": this.owner.ownerEmailId,
          
         
      }
  };
    this.router.navigate(['/ownerhome'], navigationExtras);
  }
 
 
 }