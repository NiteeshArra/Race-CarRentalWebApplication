import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { HttpClientModule } from '@angular/common/http';

import { OwnerregisterComponent } from './ownerregister/ownerregister.component';
import { HomeComponent } from './home/home.component';
import { CustomerhomeComponent } from './customerhome/customerhome.component';
import { OwnerhomeComponent } from './ownerhome/ownerhome.component';
import { ProfileComponent } from './profile/profile.component';
import { RentcarComponent } from './rentcar/rentcar.component';
import { OwnerprofileComponent } from './ownerprofile/ownerprofile.component';
import { AddcarComponent } from './addcar/addcar.component';
import { RemovecarComponent } from './removecar/removecar.component';
import * as bootstrap from "bootstrap";
import * as $ from "jquery";
import { BookcarComponent } from './bookcar/bookcar.component';
import { CurrentrentcarComponent } from './currentrentcar/currentrentcar.component';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ToastrModule } from 'ngx-toastr';
import { CustomerbookedcarComponent } from './customerbookedcar/customerbookedcar.component';
import { AppRoutingModule } from './app-routing.module';
import { PaymentComponent } from './payment/payment.component';


const appRoot: Routes = [{path: '', component: HomeComponent},
{path: 'login', component: LoginComponent},
{path: 'register', component: RegisterComponent},
{path: 'ownerregister', component: OwnerregisterComponent},
{path: 'ownerhome', component:  OwnerhomeComponent},
{path: 'customerhome', component: CustomerhomeComponent},
{path: 'profile', component: ProfileComponent},
{path: 'ownerprofile', component: OwnerprofileComponent},
{path: 'addcar', component: AddcarComponent},
{path: 'rentcar', component: RentcarComponent},
{path: 'bookcar', component: BookcarComponent},
{path: 'currentrentcar', component: CurrentrentcarComponent},
{path: 'currentrent', component: CurrentrentcarComponent},
{path: 'customerbookedcar', component: CustomerbookedcarComponent},
{path: 'removecar', component: RemovecarComponent},
{path: 'remove', component: RemovecarComponent},
{path: 'pay', component: PaymentComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    
    LoginComponent,
    RegisterComponent,
    
    OwnerregisterComponent,
    HomeComponent,
    CustomerhomeComponent,
    OwnerhomeComponent,
    ProfileComponent,
    RentcarComponent,
    OwnerprofileComponent,
    AddcarComponent,
    RemovecarComponent,
    BookcarComponent,
    CurrentrentcarComponent,
    CustomerbookedcarComponent,
    PaymentComponent,
  ],
  imports: [
    BrowserModule,
    NgbModule,
    FormsModule,    // modules
    RouterModule.forRoot(appRoot),
    HttpClientModule,
    CommonModule,
    BrowserAnimationsModule, 
    ToastrModule.forRoot(),
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
