import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentrentcarComponent } from './currentrentcar.component';

describe('CurrentrentcarComponent', () => {
  let component: CurrentrentcarComponent;
  let fixture: ComponentFixture<CurrentrentcarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CurrentrentcarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentrentcarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
