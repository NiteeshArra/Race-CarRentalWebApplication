import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-currentrentcar',
  templateUrl: './currentrentcar.component.html',
  styleUrls: ['./currentrentcar.component.css']
})
export class CurrentrentcarComponent implements OnInit {
customer:any
  customeremail:any
  currentcars:any
  car:any
  cancelcar:any
  index=0;
  constructor(public service: PersonService, private route: ActivatedRoute,public router: Router,private toastr: ToastrService) {
    this.route.queryParams.subscribe(params => {
       
        this.customeremail= params["customeremail"];
        

      
    });
    this.service.currentRentedCar(this.customeremail).toPromise().then((data: any)=> {this.currentcars =data; console.log(data)});
  }

  ngOnInit(): void {
  }

  
  async cancel(car:any) :Promise<void>{
  //  car.rentId=this.currentcars.rentId;
    //car.customerEmailId=this.currentcars.customerEmailId;
    this.service.cancel(car).subscribe();
    this.toastr.success('Your booking cancelled', '');
    await this.service.customerProfile(this.customeremail).toPromise().then((data: any)=> {this.customer =data; console.log(data)});
    
    let navigationExtras: NavigationExtras = {
      queryParams: {
          
        "customername": this.customer.customerName,
          "customeremail": this.customer.customerEmailId,
          
         
      }
  };
    this.router.navigate(['/currentrent'], navigationExtras);
   
  }


  async pay(car:any) :Promise<void>{
    //  car.rentId=this.currentcars.rentId;
      //car.customerEmailId=this.currentcars.customerEmailId;
      
      await this.service.customerProfile(this.customeremail).toPromise().then((data: any)=> {this.customer =data; console.log(data)});
      
      let navigationExtras: NavigationExtras = {
        queryParams: {
            
          "customername": this.customer.customerName,
            "customeremail": this.customer.customerEmailId,
            
           
        }
    };
      this.router.navigate(['/pay'], navigationExtras);
     
    }










  async view(){
    await this.service.customerProfile(this.customeremail).toPromise().then((data: any)=> {this.customer =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "customername": this.customer.customerName,
          "customeremail": this.customer.customerEmailId,
          
         
      }
  };
    this.router.navigate(['/customerhome'], navigationExtras);
  }

}
