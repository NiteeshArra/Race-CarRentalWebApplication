import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RemovecarComponent } from './removecar.component';

describe('RemovecarComponent', () => {
  let component: RemovecarComponent;
  let fixture: ComponentFixture<RemovecarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RemovecarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RemovecarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
