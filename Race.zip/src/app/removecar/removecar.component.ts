import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-removecar',
  templateUrl: './removecar.component.html',
  styleUrls: ['./removecar.component.css']
})
export class RemovecarComponent implements OnInit {

owner:any
  ownername:any
  owneremail:any
  cars:any
  index=0;
  constructor(public service: PersonService, private route: ActivatedRoute,public router: Router,private toastr: ToastrService) {
    this.route.queryParams.subscribe(params => {
       
      
      this.owneremail= params["owneremail"];
        

      
    });
    this.service.ownerCars(this.owneremail).toPromise().then((data: any)=> {this.cars =data; console.log(data)});
  }


  ngOnInit(): void {
  }


  async cancel(car:any) :Promise<void>{
   // car.carId=this.cars.carId;
   // car.ownerEmailId=this.cars.ownerEmailId;
    this.service.removeCar(car).subscribe();
    this.toastr.success('Car removed successfully', '');
    await  await this.service.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    
    let navigationExtras: NavigationExtras = {
      queryParams: {
          
        
          "owneremail": this.owner.ownerEmailId,
          
         
      }
  };
    this.router.navigate(['/remove'], navigationExtras);
   
  }

  async view(){
    await this.service.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "ownername": this.owner.ownerName,
          "owneremail": this.owner.ownerEmailId,
          
         
      }
  };
    this.router.navigate(['/ownerhome'], navigationExtras);
  }

}
