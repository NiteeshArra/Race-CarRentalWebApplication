import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PersonService {

  public isUserLogged: boolean;
  public customerData: any;


  constructor(public httpClient: HttpClient) { 
    this.isUserLogged = false;
  }
  public setUserLoggedIn(): void {
    this.isUserLogged = true;
  }
  public getUserLogged(): any {
    return this.isUserLogged;
  }

  //When user is click on logout button
  public setUserLoggedOut(): void {
    this.isUserLogged = false;
  }


  public setCustomer(customer: any): any {
    this.customerData =customer;
  }


  public getCustomer(): any {
    return this.customerData;
  }


  loginAuthentication(emailId:any, password:any) :any{
    return this.httpClient.get('getCustomer/'+ emailId+ "/" + password);
  }

  registerCustomerDetails(customerForm: any): any {
    return this.httpClient.post('registerCustomer/', customerForm);
  }

  registerOwnerDetails(ownerForm: any): any {
    return this.httpClient.post('registerOwner/', ownerForm);
  }

  addcarDetails(addcarForm: any): any {
    return this.httpClient.post('addCar/',addcarForm);
  }


  bookCar(bookcarForm: any): any {
    return this.httpClient.post('bookCar/',bookcarForm);
  }

  ownerLoginAuthentication(emailId:any, password:any) :any{
    return this.httpClient.get('getOwner/'+ emailId+ "/" + password);
  }

  customerProfile(emailId:any):any{
    return this.httpClient.get('customerProfile/'+ emailId);
  }

  ownerProfile(emailId:any):any{
    return this.httpClient.get('ownerProfile/'+ emailId);
  }

  getCars(searchForm:any):any{
    return this.httpClient.get('getCars/'+ searchForm);
  }

  ownerCars(emailId:any):any{
    return this.httpClient.get('ownerCars/'+ emailId);
  }


  currentRentedCar(emailId:any):any{
    return this.httpClient.get('currentrentedcar/'+ emailId);
  }


  cancel(car:any) :any{
    return this.httpClient.post('cancel/', car);
  }

  removeCar(car:any) :any{
    return this.httpClient.post('remove/', car);
  }

  customerbookedcar(emailId:any):any{
    return this.httpClient.get('customerbookedcar/'+ emailId);
  }


}
