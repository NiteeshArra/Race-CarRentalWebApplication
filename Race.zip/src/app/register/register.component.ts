import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';
@Component({
  selector: 'app-register',
  templateUrl:'./register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  
  register: any;
  

  constructor(public router: Router, public service: PersonService,private toastr: ToastrService) { }

  ngOnInit(){
  }


  registerCustomer(customerForm: any) : void {
    console.log(customerForm);
    if(customerForm.customerEmailId!="" && customerForm.customerName!="" && customerForm.password!="" && customerForm.repassword!="" && customerForm.gender!="" && customerForm.customerLicenseNumber!="" && customerForm.customerPhoneNumber!="" && customerForm.state!="" && customerForm.city!="" && customerForm.postal!="" )
    {
    this.service.registerCustomerDetails(customerForm).subscribe((result: any) => console.log(result));
   // alert("successfully registered ");
   this.toastr.success('successfully registered', '');
    this.router.navigate(['login']);
  }
  else
  {
   this.toastr.error('Please enter the details', '');
  }

}
}
