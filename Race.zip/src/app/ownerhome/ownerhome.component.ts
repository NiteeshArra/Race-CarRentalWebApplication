import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-ownerhome',
  templateUrl: './ownerhome.component.html',
  styleUrls: ['./ownerhome.component.css']
})
export class OwnerhomeComponent implements OnInit {
 
  ownername:any;
  ownerregister: any;
  owneremail:any;
  owner:any;
 
  constructor(public router: Router, public personService: PersonService, private route: ActivatedRoute){
    this.route.queryParams.subscribe(params => {
        this.ownername= params["ownername"];
        this.owneremail= params["owneremail"];

      
    });}

  ngOnInit() {
  }


  async viewProfile(){
    await this.personService.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "ownername": this.owner.ownerName,
          "owneremail": this.owner.ownerEmailId,
          "ownerlicensenumber": this.owner.ownerLicenseNumber,
          "ownerphonenumber": this.owner.ownerPhoneNumber,
          "state": this.owner.state,
          "city": this.owner.city,
          "postal": this.owner.postal
         
      }
  };
    this.router.navigate(['/ownerprofile'], navigationExtras);
  }

  async addCar(){
    await this.personService.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "ownername": this.owner.ownerName,
          "owneremail": this.owner.ownerEmailId,
         
         
      }
  };
    this.router.navigate(['/addcar'], navigationExtras);
  }
  
  async customerBookedCars(){
    await this.personService.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "ownername": this.owner.ownerName,
          "owneremail": this.owner.ownerEmailId,
         
         
      }
  };
    this.router.navigate(['/customerbookedcar'], navigationExtras);
  }

  async removeCars(){
    await this.personService.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "ownername": this.owner.ownerName,
          "owneremail": this.owner.ownerEmailId,
         
         
      }
  };
    this.router.navigate(['/removecar'], navigationExtras);
  }
}


