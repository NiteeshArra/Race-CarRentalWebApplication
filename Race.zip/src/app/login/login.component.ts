import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PersonService } from '../person.service';
@Component({
  selector: 'app-login',
  templateUrl:'./login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: any;
  register :any;
  customer: any;
  constructor(public router: Router, public personService: PersonService,private toastr: ToastrService) { 
    this.user = {emailId: '', password: ''};
  }

  ngOnInit() {
  }


  loginSubmit() {
    console.log('Data Recieved : ' + this.user.emailId);
  }

  async submitLoginForm(loginForm: any) {       //validateUser()
    console.log(loginForm);

   if(loginForm.emailId === 'admin' && loginForm.password === 'admin') {
      this.personService.setUserLoggedIn();    //return true;
      //this.router.navigate(['products']);
      alert("success");
    }
    else{
      if(loginForm.person === "customer")
      {
    await this.personService.loginAuthentication(loginForm.emailId,loginForm.password).toPromise().then((data: any)=> {this.user =data; console.log(data)});
    // console.log(this.user.customerEmailId);
    // console.log(loginForm.customerEmailId);
     //console.log(this.register);
     if(this.user){
      this.personService.setCustomer(this.user);  
      this.customer =this.user;
    //  alert("Login success");
      let navigationExtras: NavigationExtras = {
        queryParams: {
            "customername": this.user.customerName,
            "customeremail": this.user.customerEmailId
        }
    };
      this.router.navigate(['customerhome'], navigationExtras);
     }

      else{
    //  alert("Invalid Login ");
    this.toastr.error('Invalid Login', '');
     }
    }
    else if(loginForm.person === "owner"){
      await this.personService.ownerLoginAuthentication(loginForm.emailId,loginForm.password).toPromise().then((data: any)=> {this.user =data; console.log(data)});
    // console.log(this.user.customerEmailId);
    // console.log(loginForm.customerEmailId);
     //console.log(this.register);
     if(this.user){

      
     // alert("Login success");
      let navigationExtras: NavigationExtras = {
        queryParams: {
            "ownername": this.user.ownerName,
            "owneremail": this.user.ownerEmailId
        }
    };
      
      this.router.navigate(['ownerhome'], navigationExtras);
     }

      else{
     // alert("Invalid Login ");
     this.toastr.error('Invalid Login', '');
     }

    }


    }
    
  

  }
}
