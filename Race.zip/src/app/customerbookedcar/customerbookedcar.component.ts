import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { PersonService } from '../person.service';

@Component({
  selector: 'app-customerbookedcar',
  templateUrl: './customerbookedcar.component.html',
  styleUrls: ['./customerbookedcar.component.css']
})
export class CustomerbookedcarComponent implements OnInit {

ownername:any
owneremail:any
bookings:any
owner:any
index=0;
  constructor(public router: Router,public service: PersonService, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
        this.ownername= params["ownername"];
        this.owneremail= params["owneremail"];
       
        

      
    });
    this.service.customerbookedcar(this.owneremail).toPromise().then((data: any)=> {this.bookings =data; console.log(data)});

  
  }

  ngOnInit(): void {
  }

  async view(){
    await this.service.ownerProfile(this.owneremail).toPromise().then((data: any)=> {this.owner =data; console.log(data)});
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "ownername": this.owner.ownerName,
          "owneremail": this.owner.ownerEmailId,
          
         
      }
  };
    this.router.navigate(['/ownerhome'], navigationExtras);
  }

}
