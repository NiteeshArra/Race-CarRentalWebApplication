import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerbookedcarComponent } from './customerbookedcar.component';

describe('CustomerbookedcarComponent', () => {
  let component: CustomerbookedcarComponent;
  let fixture: ComponentFixture<CustomerbookedcarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerbookedcarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerbookedcarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
